#!/bin/bash

ls

java -jar scrum-ladders.jar
